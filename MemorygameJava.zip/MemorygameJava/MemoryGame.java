/*
 * Tis is a first version of an attempt to implement "the memory game" using java swing.
 * The design could be improved by putting the card class in a seperate file.
 * The program still have few clitches to be fixed.
 * I left few comment there in case I decided to go back and debug the program some more.
 */
//package memorygame;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Alae Loukili 2018
 */
public class MemoryGame extends JFrame {

   /**
     * @param args the command line arguments
     */
    final int SIZE = 20;
    JButton[]  buttons = new JButton[SIZE];//creating an array of Buttons
    ImageIcon[] icons = new ImageIcon[SIZE];//creating an array of Image Icons
    ImageIcon IconBack = new ImageIcon("image/b2fv.png");//back of the card Icon
    
    Card [] cards;//array of cards
    
    int numberOfClicks =0;
    int numberOfMatches = 0;
     JLabel labKlik  = new JLabel("number of clicks: ");
    JTextField boxKlik = new JTextField(3);
    JLabel labMatched  = new JLabel("number of matches: ");
    JTextField boxMatched = new JTextField(3);
    
   MemoryGame()
    {
   this.cards = new Card[SIZE];
   JPanel pan =  new JPanel();
   JPanel panel = new JPanel();
   
   for (short i =0 ; i < (SIZE/2); i++ ){
  icons[i] = new ImageIcon("image/" + (4 * i + 1) +".png");

 // icons[i] = new ImageIcon("image/" + ((int)(Math.random() * (54)) + 1) +".png");
  icons[i + SIZE/2] = icons[i];
  }
   //shuffling the array
   for (short i =0 ; i < SIZE; i++ )
   {
       int j = (int) ( Math.random()* SIZE );
       ImageIcon temp ;
       temp = icons[i];
       icons[i] = icons[j];
       icons[j] = temp;
   
   }
   
   //###########################
  for (short i =0 ; i < SIZE; i++ ){
  cards[i] = new Card(); //create instance of Card class
 // icons[i] = new ImageIcon("image/" + ((int)(Math.random() * (54)) + 1) +".png");
  buttons[i] = new JButton(icons[i]);
      pan.add(buttons[i]);
      
   cards[i].setButton(buttons[i]); //link button to card
  }

  
    //start the cards on their face flipped false, matched false
  for (short i =0 ; i < SIZE; i++ ){
        
      buttons[i].setIcon(IconBack); 
      pan.add(buttons[i]);
        }
 
    pan.setLayout(new GridLayout(4, SIZE/4, 5, 5)); //Assuming here that SIZE is greater or equal to 4. 
       
    
   
    panel.setBorder(new LineBorder(Color.BLACK, 3));
    panel.setBorder(new TitledBorder("Statistics: "));
    panel.add(labKlik);
    panel.add(boxKlik);
    panel.add(labMatched);
    panel.add(boxMatched);
    
    add(panel,  BorderLayout.NORTH  );
    add(pan,    BorderLayout.CENTER );
    
    Clicker cl = new Clicker();
    
    for (short i =0; i < SIZE; i++)
        buttons[i].addActionListener(cl);

    //pack();
    }
    public static void main(String[] args) {
        
        
         MemoryGame frame = new MemoryGame();
    frame.setTitle("Display Sixten Cards");
    frame.setSize(800, 500);
    frame.setLocationRelativeTo(null); // Center the frame
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
    }
    
    
    class Clicker implements ActionListener
    {

        @Override
        public void actionPerformed(ActionEvent e) {
          
        numberOfClicks++;
        boxKlik.setText( Integer.toString(numberOfClicks));
       
        for (short i = 0; i < SIZE; i++)
            {
               // System.out.println("I am outer looping!");
                    
            if (cards[i].getButton() == e.getSource()) {
                
                if (!cards[i].getMatched()){
                     cards[i].setFlipped(true);
                     buttons[i].setIcon(icons[i]);
                    for (short j = 0; j < SIZE; j++)
                    {//System.out.println("I am looping!");
                        if ( i != j && cards[i].equals(cards[j]) && cards[j].getFlipped())
                        {
                            cards[i].setMatched(true);
                            cards[j].setMatched(true);
                           // cards[i].setFlipped(true);
                            cards[j].setFlipped(true);
                            numberOfMatches++;
                            boxMatched.setText( Integer.toString(numberOfMatches));
                    
                        }//end equal cards
                        else
                        {
                            for (short k =0; k < SIZE; k++) //needs work
                            {
                                if ( k != j && k != i && i != j && cards[j].getFlipped() && cards[k].getFlipped() && !cards[j].getMatched() && !cards[k].getMatched() )
                                {
                                    cards[j].setFlipped(false);
                                    cards[k].setFlipped(false);
                                    buttons[j].setIcon(IconBack);
                                   buttons[k].setIcon(IconBack);
                                                              
                                }//end f flip j and k back
                            
                                                        
                            }//end for k
                        }//end else
                    }//end inner for
                }//end if not matched
                else {
               // buttons[i].setIcon(icons[i]); 
               
               //cards[i].setFlipped(!cards[i].getFlipped());
              
                }
               
            }//end outer if
            
            }//end outer for
       if (numberOfMatches == SIZE/2){
       
       System.out.println("\nStop clicking! Would you");
       }
        }//end actionPerformed
    }//end Clicker
}//end MemoryGame


 class Card {

boolean flipped;
boolean matched;
//ImageIcon icon; //this linked to the button not the class card. Maybe it should not be here
JButton botton;

Card()
{

    flipped = false; //card is on its face. we see only the back
    matched = false; // card is not matched to any other card
    //icon = new ImageIcon("image/b2fv.png");
    botton = new JButton("image/b2fv.png");
}


boolean getFlipped()
{
    return flipped;
}

void setFlipped(boolean boo)
{
    flipped = boo;
}

boolean getMatched()
{
    return matched;
}

void setMatched(boolean bo)
{
    matched = bo;
}

//ImageIcon getIcon()
//{
//    return icon;
//}
//
//void setIcon(ImageIcon ic)
//{
//    icon = ic;
//}

JButton getButton()
{
    return botton;
}

void setButton(JButton butt)
{
    botton = butt;
}



@Override
  public boolean equals(Object other){
    // Card otherCard = (Card) other;
      if (other == null) return false;
      return getButton().getIcon() == ((Card)other).getButton().getIcon();
   }
}//end card